{
	'name': "Purchase Order Template",
	'author': "Prime Minds Consulting",
	'version': "12.0.1.1 updated on 26-jun",
	'website': "www.pmcpl.com",
	'depends': ['base', "purchase"],
	'demo': [],
	'data': [
		'report/report.xml',
		'template/template.xml',
		'views/views.xml',
	],
	'installable': 'True',
	'auto install': 'False',
}
