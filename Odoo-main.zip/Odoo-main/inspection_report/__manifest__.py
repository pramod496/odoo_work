{
	'name':"Inspection Report ",
	'author':"Prime Minds",
	'version':"1.0 updated on Dec-20",
	'website':"http//www.primemindz.com",
	
	'depends':['base',"stock"],
	'demo':[],
	'data':['report/report.xml',
			'template/template.xml',
			'views/views.xml'],
	'installable':'True',
	'auto install':'False',
}
