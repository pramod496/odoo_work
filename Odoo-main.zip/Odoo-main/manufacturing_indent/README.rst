Indent Management - MRP v10
===========================
The aim is to have a complete module to manage all MRP product indents. When we create a MRP
order, it automatically create a indent to the warehouse manager to approve the raw materials.
And also if the Manufacturing team need a product for there internal use, they can also create a
indent to the warehouse team for the same.

Features
========

* MRP indents create automatically.
* Each MRP indent can approve by the warehouse manager.
* Raw materials available only after the approval of indent by warehouse manager.
* Manufacturing Plants need some goods for internal purpose, then they can indent it too with reason.

Credits
=======
Nikhil Krishnan @ cybrosys, nikhil@cybrosys.in