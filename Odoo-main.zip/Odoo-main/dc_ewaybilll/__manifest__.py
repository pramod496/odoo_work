{
	'name':" DC e-waybill",
	'author':"Prime Minds Consulting",
	'version':"1.0.1",
	'website':"https://primeminds.co",
	
	'depends':['base',"sales_team","sale","account","product",'stock'],
	'demo':[],
	'data':['views/stock_picking_view.xml'],
	'installable':'True',
	'auto install':'False',
}
