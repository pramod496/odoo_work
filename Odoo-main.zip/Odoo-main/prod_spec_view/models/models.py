# # -*- coding: utf-8 -*-

# from odoo import api, models, fields, _

# class StockPicking(models.Model):
#     _inherit = 'stock.picking'

#     @api.model
#     def create(self, vals):
#         return 1 / 0