{
	'name':"Quotation Report",
	'author':"pmcpl",
	'version':"1.0 updated on July-16",
	'website':"http//www.pmcpl.com",
	
	'depends':[
		'base',
		'sales_team',
		'sale',
		'sale_to_mrp',],
	'demo':[],
	'data':[
		'report/report.xml',
		'template/template.xml',
		'views/views.xml',
	],
	'installable':'True',
	'auto install':'False',
}
