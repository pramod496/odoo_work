{
	'name':"Goods Receipt &  Inspection Report",
	'author':"PMCPL",
	'version':"12.0.0.2 updated on 5-july",
	'website':"https://primeminds.co",
	
	'depends':['base','stock','quality','sale_to_mrp'],
	'demo':[],
	'data':[
			'report/report.xml',
			'template/template.xml',
			'views/views.xml'
			],
	'installable':'True',
	'auto install':'False',
}
