from . import res_company_inherit
from . import res_config_settings_inherit
